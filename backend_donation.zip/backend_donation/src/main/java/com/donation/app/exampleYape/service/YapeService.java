
package com.donation.app.exampleYape.service;

import com.donation.app.exampleYape.model.ChargePaymentRequestDTO;
import com.donation.app.exampleYape.model.ChargePaymentResponse;

import reactor.core.publisher.Mono;

public interface YapeService {

    Mono<ChargePaymentResponse> chargePayment(
            ChargePaymentRequestDTO body
    );
}
