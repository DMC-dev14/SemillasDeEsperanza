package com.donation.app.exampleYape.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class YapeGenerateTokenRequest {
    private String phoneNumber;
    private String otp;
    private String request_id;
}
